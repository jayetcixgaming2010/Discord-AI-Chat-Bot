/**
 * Shared helper utilities for interaction handlers.
 * Provides common guard checks, state persistence, and content delivery helpers.
 */

import fs from 'fs/promises';
import path from 'path';

import { AttachmentBuilder, ChannelType, MessageFlags } from 'discord.js';

import { TEMP_DIR } from '../core/paths.js';
import { ENABLE_NANO_BANANA_MODE } from '../constants.js';
import {
  getChannelSettings,
  getServerSettings,
  saveStateToFile,
  isUserBlacklisted,
} from '../state/botState.js';
import { createSharedTextLink } from '../services/textSharingService.js';
import { resolveLockScope } from '../services/scopeResolution.js';
import { logError } from '../utils/errorHandler.js';
import {
  applyEmbedFallback,
  createStatusEmbed,
  ensureAdministrator,
  ensureGuildInteraction,
  replyWithEmbed,
} from '../utils/discord.js';

/** Persists the current bot state to disk. */
export async function persistStateChange() {
  await saveStateToFile();
}

/**
 * Ensures the interaction is in a guild and the user is an administrator.
 * Replies with an error embed if either check fails.
 * @returns {Promise<boolean>} True if the user is a guild admin.
 */
export async function requireGuildAdmin(interaction) {
  const inGuild = await ensureGuildInteraction(interaction, 'This command cannot be used in DMs.');
  if (!inGuild) {
    return false;
  }
  return ensureAdministrator(interaction);
}

/**
 * Replies with a "Feature Disabled" embed.
 */
export async function replyFeatureDisabled(interaction, description) {
  return replyWithEmbed(interaction, {
    variant: 'warning',
    title: 'Feature Disabled',
    description,
  });
}

export function getClearMemoryDisabledReason(interaction) {
  const channelId = interaction.channelId ?? interaction.channel?.id;
  const channelLock = channelId
    ? getChannelSettings(channelId).channelWideChatHistory
    : false;

  const guildId = interaction.guild?.id;
  const serverLock = guildId
    ? getServerSettings(guildId).serverChatHistory
    : false;

  const lockScope = resolveLockScope(channelLock, serverLock);

  if (lockScope === 'channel') {
    return 'Clearing chat history is not enabled for this channel, channel-wide chat history is active.';
  }

  if (lockScope === 'server') {
    return 'Clearing chat history is not enabled for this server, server-wide chat history is active.';
  }

  return null;
}

export function getCustomPersonalityDisabledReason(interaction) {
  const channelId = interaction.channelId ?? interaction.channel?.id;
  const channelLock = channelId
    ? getChannelSettings(channelId).customChannelPersonality
    : false;

  const guildId = interaction.guild?.id;
  const serverLock = guildId
    ? getServerSettings(guildId).customServerPersonality
    : false;

  const lockScope = resolveLockScope(channelLock, serverLock);

  if (lockScope === 'channel') {
    return 'Custom personality is not enabled for this channel, channel-wide personality is active.';
  }

  if (lockScope === 'server') {
    return 'Custom personality is not enabled for this server, server-wide personality is active.';
  }

  return null;
}

export function getNanoBananaDisabledReason(interaction) {
  if (!ENABLE_NANO_BANANA_MODE) {
    return 'Nano Banana mode is disabled in this bot configuration.';
  }

  if (getClearMemoryDisabledReason(interaction)) {
    return 'Nano Banana mode is not available while server-wide or channel-wide chat history is active.';
  }

  if (getCustomPersonalityDisabledReason(interaction)) {
    return 'Nano Banana mode is not available while server-wide or channel-wide personality instructions are active.';
  }

  return null;
}

export function getResponseStyleDisabledReason(interaction) {
  const guildId = interaction.guild?.id;
  if (!guildId) return null;

  const channelId = interaction.channelId ?? interaction.channel?.id;
  const channelSetting = channelId ? getChannelSettings(channelId).responseStyle : 'decide';

  const setting = getServerSettings(guildId).responseStyle;
  const lockScope = resolveLockScope(
    channelSetting,
    setting,
    (value) => Boolean(value && value !== 'decide'),
  );

  if (lockScope === 'channel') {
    return 'The response style is locked to the channel-wide preference.';
  }

  if (lockScope === 'server') {
    return 'The response style is locked to the server-wide preference.';
  }

  return null;
}

export function getAlwaysRespondDisabledReason(interaction) {
  if (interaction.channel?.type === ChannelType.DM) {
    return 'Always respond is always active in direct messages.';
  }
  const channelId = interaction.channelId ?? interaction.channel?.id;
  if (channelId && getChannelSettings(channelId).alwaysRespond) {
    return 'The bot is configured to always respond in this channel.';
  }
  return null;
}

export function getResponseActionButtonsDisabledReason(interaction) {
  const guildId = interaction.guild?.id;
  if (!guildId) return null;

  const channelId = interaction.channelId ?? interaction.channel?.id;
  const channelSetting = channelId ? getChannelSettings(channelId).settingsSaveButton : 'decide';
  const setting = getServerSettings(guildId).settingsSaveButton;
  const lockScope = resolveLockScope(
    channelSetting,
    setting,
    (value) => value === 'on' || value === 'off',
  );

  if (lockScope === 'channel') {
    return channelSetting === 'on'
      ? 'Response action buttons are forced ON by channel settings.'
      : 'Response action buttons are disabled by channel settings.';
  }

  if (lockScope === 'server') {
    return setting === 'on'
      ? 'Response action buttons are forced ON by server settings.'
      : 'Response action buttons are disabled by server settings.';
  }

  return null;
}

/**
 * Ensures the interaction user is not blacklisted in the current guild.
 * Replies with an error embed if the user is blacklisted.
 * @returns {Promise<boolean>} True if the user is allowed.
 */
export async function ensureInteractionNotBlacklisted(interaction) {
  if (!interaction.guild) {
    return true;
  }

  if (!isUserBlacklisted(interaction.guild.id, interaction.user.id)) {
    return true;
  }

  await replyWithEmbed(interaction, {
    variant: 'error',
    title: 'Blacklisted',
    description: 'You are blacklisted and cannot use this interaction.',
  });

  return false;
}

/**
 * Creates an embed for saved/downloaded content.
 */
export function createSavedContentEmbed(title, description, sharedTextLink = null) {
  const urlLine = sharedTextLink ? `\n\n${sharedTextLink}` : '';
  return createStatusEmbed({
    variant: 'primary',
    title,
    description: `${description}${urlLine}`,
  });
}

/**
 * Appends a shared URL to an already-sent DM once URL generation completes.
 */
async function appendSharedLinkToDm(dmMessage, { title, description, text }) {
  try {
    const sharedTextLink = await createSharedTextLink(text);
    const updatedEmbed = createSavedContentEmbed(title, description, sharedTextLink);
    await dmMessage.edit({ embeds: [updatedEmbed] });
  } catch (error) {
    logError('SendSavedContentToUserUpdateDM', error, {
      messageId: dmMessage?.id,
      channelId: dmMessage?.channelId,
    });
  }
}

async function sendSavedContentDm(user, savedContentEmbed, file) {
  return user.send({
    embeds: [savedContentEmbed],
    files: [file],
  });
}

/**
 * Writes text to a temp file and delivers it to the user via DM immediately.
 * Shared URL generation is handled in the background and updates the DM later.
 */
export async function sendSavedContentToUser(
  interaction,
  {
    text,
    fileBaseName,
    title,
    description,
    successTitle,
    successDescription,
    failureDescription,
  },
) {
  const filePath = path.join(TEMP_DIR, `${fileBaseName}_${interaction.id}.md`);
  const fileName = `${fileBaseName}.md`;

  try {
    await fs.writeFile(filePath, text, 'utf8');
    const file = new AttachmentBuilder(filePath, { name: fileName });
    const savedContentEmbed = createSavedContentEmbed(title, description);

    if (interaction.channel.type === ChannelType.DM) {
      await interaction.deferUpdate();
      const dmMessage = await sendSavedContentDm(interaction.user, savedContentEmbed, file);
      void appendSharedLinkToDm(dmMessage, { title, description, text });
      return;
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    try {
      const dmMessage = await sendSavedContentDm(interaction.user, savedContentEmbed, file);
      void appendSharedLinkToDm(dmMessage, { title, description, text });

      const successEmbed = createStatusEmbed({
        variant: 'success',
        title: successTitle,
        description: successDescription,
      });

      await interaction.editReply(applyEmbedFallback(interaction.channel, {
        embeds: [successEmbed],
      }));
    } catch (error) {
      logError('SendSavedContentToUserDM', error, {
        userId: interaction.user?.id,
        interactionId: interaction.id,
      });
      await interaction.editReply(applyEmbedFallback(interaction.channel, {
        embeds: [
          createStatusEmbed({
            variant: 'warning',
            title: 'DM Delivery Failed',
            description: failureDescription,
          }),
          savedContentEmbed,
        ],
        files: [file],
        flags: MessageFlags.Ephemeral,
      }));
    }
  } finally {
    try {
      await fs.unlink(filePath);
    } catch (error) {
      if (error?.code !== 'ENOENT') {
        logError('SendSavedContentToUserCleanup', error, { filePath });
      }
    }
  }
}
